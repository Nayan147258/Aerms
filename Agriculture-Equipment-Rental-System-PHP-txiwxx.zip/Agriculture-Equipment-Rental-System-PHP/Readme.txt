
How to run the Agriculture Rental Management System (AERMS)

1.Download the Project zip file

2.Extract the file and copy aerms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name aermsdb

6.Import aermsdb.sql file (given inside the zip package in SQL file folder)

7.Run the script http://localhost/aerms (frontend)


*********************Credential for Admin Panel***************************

Username: admin
Password: Test@123


*********************Credential for User Panel***************************

Email: testuser@t.com
Password: Test@123

OR Register a new user.
